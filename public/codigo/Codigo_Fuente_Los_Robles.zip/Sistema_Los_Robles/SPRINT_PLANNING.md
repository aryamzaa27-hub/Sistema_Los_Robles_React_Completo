# Sprint Planning — Sistema Los Robles

## Sprint 1. Planeación y diseño
- 5 días, 32 horas estimadas, 10 puntos.
- HU-01 Planeación: terminada.
- HU-02 Diseño: en proceso.

## Sprint 2. Desarrollo
- 5 días, 84 horas estimadas, 16 puntos.
- HU-03 Frontend: en proceso. Tiene formulario, historial, contador, fechas y botón para eliminar todos los reportes con confirmación.
- HU-04 Backend y base de datos: pendiente.

## Sprint 3. Pruebas y publicación
- 5 días, 88 horas estimadas, 12 puntos.
- HU-05 Pruebas completas: en proceso (solo pruebas manuales iniciales).
- HU-06 Publicación: pendiente.
- HU-07 Mantenimiento: pendiente.

## Product Backlog
| Historia | Actividad | Puntos | Sprint | Estado |
|---|---|---:|---:|---|
| HU-01 | Planeación | 5 | 1 | Terminada |
| HU-02 | Diseño | 5 | 1 | En proceso |
| HU-03 | Frontend | 8 | 2 | En proceso |
| HU-04 | Backend | 8 | 2 | Pendiente |
| HU-05 | Pruebas | 5 | 3 | En proceso; pruebas iniciales |
| HU-06 | Publicación | 5 | 3 | Pendiente |
| HU-07 | Mantenimiento | 2 | 3 | Pendiente |

Fuente original de seguimiento: https://github.com/aryamzaa27-hub/Sistema_Los_Robles_React_Completo/blob/main/SPRINT_PLANNING.md
