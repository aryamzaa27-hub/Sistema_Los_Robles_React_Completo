# Sistema de Administración Comunitaria Los Robles

Proyecto académico en React + Vite. Permite consultar avisos, servicios y registrar reportes o sugerencias.

## Funciones observables
- Menú: Inicio, Avisos, Servicios, Contacto e Historial.
- Formulario de reportes, confirmación y registro local en `localStorage`.
- Historial con nombre, mensaje, fecha y contador.
- Botón para borrar todos los reportes con confirmación.

## Ejecutar localmente
1. Instalar Node.js.
2. En esta carpeta, ejecutar `npm install`.
3. Ejecutar `npm run dev`.
4. Abrir la dirección que muestre Vite.

## Limitaciones
El registro se guarda en el navegador; no existe una base de datos ni backend conectado. Las pruebas completas y el despliegue público del sistema siguen pendientes.

Repositorio de origen: https://github.com/aryamzaa27-hub/Sistema_Los_Robles_React_Completo

Esta copia de entrega reúne los archivos necesarios para ejecutar el frontend, sin incluir la carpeta `node_modules`.
